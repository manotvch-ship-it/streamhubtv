package com.streamhub.tv;

import java.util.ArrayList;
import java.util.List;

public class ChannelRepository {

    public static List<Channel> getAllChannels() {
        List<Channel> channels = new ArrayList<>();

        // ── ESPORTES (YouTube) ──────────────────────────────────────────────
        channels.add(new Channel(1,
            "Cazé TV", "CAZ", "Esportes",
            "Futebol e esportes ao vivo",
            "45.2k",
            "https://images.unsplash.com/photo-1579952363873-27f3bade9f55?q=80&w=600&fit=crop",
            null,
            "https://www.youtube.com/@CazeTVOficial/live",
            true, false));

        channels.add(new Channel(2,
            "GE TV", "GE", "Esportes",
            "Programacao esportiva - ge.globo",
            "12.1k",
            "https://images.unsplash.com/photo-1461896836934-ffe607ba8211?q=80&w=600&fit=crop",
            null,
            "https://www.youtube.com/@getv/live",
            true, false));

        channels.add(new Channel(3,
            "SBT", "SBT", "Entretenimento",
            "Programacao SBT ao vivo",
            "89.5k",
            "https://images.unsplash.com/photo-1585647347483-22b66260dfff?q=80&w=600&fit=crop",
            null,
            "https://www.youtube.com/@SBT/live",
            true, false));

        channels.add(new Channel(4,
            "CNN Brasil", "CNN", "Noticias",
            "Jornal da CNN ao vivo 24h",
            "34.0k",
            "https://images.unsplash.com/photo-1495020689067-958852a7765e?q=80&w=600&fit=crop",
            null,
            "https://www.youtube.com/@CNNBrasil/live",
            true, false));

        channels.add(new Channel(5,
            "Band News TV", "BND", "Noticias",
            "Noticias 24h ao vivo",
            "21.3k",
            "https://images.unsplash.com/photo-1504711434969-e33886168f5c?q=80&w=600&fit=crop",
            null,
            "https://www.youtube.com/@BandNewsTV/live",
            true, false));

        channels.add(new Channel(6,
            "Record News", "REC", "Noticias",
            "Jornalismo 24h ao vivo",
            "18.7k",
            "https://images.unsplash.com/photo-1523995462485-3d171b5c8fa9?q=80&w=600&fit=crop",
            null,
            "https://www.youtube.com/@recordnews/live",
            true, false));

        channels.add(new Channel(7,
            "Band Sports", "BSP", "Esportes",
            "Esportes - NBA, NFL ao vivo",
            "15.4k",
            "https://images.unsplash.com/photo-1519861531473-9200262188bf?q=80&w=600&fit=crop",
            null,
            "https://www.youtube.com/@Band/live",
            true, false));

        // ── HLS DIRETO (player interno ExoPlayer) ───────────────────────────
        channels.add(new Channel(8,
            "TV Camara", "CAM", "Governo",
            "Sessoes ao vivo do Congresso Nacional",
            "8.4k",
            "https://images.unsplash.com/photo-1541872703-74c5e44368f9?q=80&w=600&fit=crop",
            "https://stream3.camara.gov.br/tv1/manifest.m3u8",
            "https://www.youtube.com/@TVCamara/live",
            true, true));

        channels.add(new Channel(9,
            "TV Senado", "SEN", "Governo",
            "Debates e sessoes ao vivo",
            "5.2k",
            "https://images.unsplash.com/photo-1589829545856-d10d557cf95f?q=80&w=600&fit=crop",
            "https://stream2.senado.leg.br/tv/channel-1/master.m3u8",
            "https://www.youtube.com/@TVSenado/live",
            true, true));

        channels.add(new Channel(10,
            "TV Aparecida", "APA", "Religioso",
            "Programacao religiosa ao vivo",
            "22.1k",
            "https://images.unsplash.com/photo-1529007196863-d07650a3f0ea?q=80&w=600&fit=crop",
            "https://dfr80qz435crc.cloudfront.net/EFGH/Amagi/TV_Aparecida/TV_Aparecida_BR/TV_Aparecidap1080.m3u8",
            "https://www.youtube.com/@tvaparecidaoficial/live",
            true, true));

        channels.add(new Channel(11,
            "TV Novo Tempo", "NTM", "Religioso",
            "Transmissao 24h adventista",
            "9.8k",
            "https://images.unsplash.com/photo-1499209974431-9dddcece7f88?q=80&w=600&fit=crop",
            "https://stream.live.novotempo.com/tv/smil:tvnovotempo.smil/playlist.m3u8",
            "https://www.youtube.com/@novotempotv/live",
            true, true));

        channels.add(new Channel(12,
            "SESC TV", "SES", "Entretenimento",
            "Cultura e entretenimento",
            "6.7k",
            "https://images.unsplash.com/photo-1598488035139-bdbb2231ce04?q=80&w=600&fit=crop",
            "https://psix79kagi.singularcdn.net.br/live/0195ede1-c23c-7078-8f2a-25f982a9fc91/s1/playlist-1080p.m3u8",
            "https://www.youtube.com/@sescsp/live",
            true, true));

        channels.add(new Channel(13,
            "TV Cultura", "CUL", "Entretenimento",
            "Cultura brasileira ao vivo",
            "11.3k",
            "https://images.unsplash.com/photo-1514525253161-7a46d19cd819?q=80&w=600&fit=crop",
            "https://d3uj5e7ot6q1uh.cloudfront.net/out/v1/a06bbb228f1745d0a2e06bfff1ae5a0e/index.m3u8",
            "https://www.youtube.com/@tvcultura/live",
            true, true));

        channels.add(new Channel(14,
            "TV Brasil", "BRS", "Governo",
            "EBC - TV publica brasileira",
            "7.6k",
            "https://images.unsplash.com/photo-1526374965328-7f61d4dc18c5?q=80&w=600&fit=crop",
            "https://tvbrasilgov.akamaized.net/hls/live/2002073/TVBrasil/master.m3u8",
            "https://www.youtube.com/@tvbrasil/live",
            true, true));

        return channels;
    }

    public static List<String> getCategories() {
        List<String> cats = new ArrayList<>();
        cats.add("Todos");
        cats.add("Esportes");
        cats.add("Noticias");
        cats.add("Entretenimento");
        cats.add("Governo");
        cats.add("Religioso");
        return cats;
    }

    public static List<Channel> getByCategory(String cat) {
        if (cat.equals("Todos")) return getAllChannels();
        List<Channel> result = new ArrayList<>();
        for (Channel c : getAllChannels()) {
            if (c.category.equals(cat)) result.add(c);
        }
        return result;
    }
}

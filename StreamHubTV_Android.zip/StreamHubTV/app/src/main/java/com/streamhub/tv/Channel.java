package com.streamhub.tv;

public class Channel {
    public int id;
    public String title;
    public String shortName;
    public String category;
    public String currentShow;
    public String viewers;
    public String imageUrl;
    public String streamUrl;    // HLS M3U8 URL (null se for YouTube)
    public String youtubeUrl;   // URL do YouTube ao vivo
    public boolean isLive;
    public boolean isHLS;       // true = player interno, false = abre YouTube

    public Channel(int id, String title, String shortName, String category,
                   String currentShow, String viewers, String imageUrl,
                   String streamUrl, String youtubeUrl, boolean isLive, boolean isHLS) {
        this.id = id;
        this.title = title;
        this.shortName = shortName;
        this.category = category;
        this.currentShow = currentShow;
        this.viewers = viewers;
        this.imageUrl = imageUrl;
        this.streamUrl = streamUrl;
        this.youtubeUrl = youtubeUrl;
        this.isLive = isLive;
        this.isHLS = isHLS;
    }
}

package com.streamhub.tv;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.OptIn;
import androidx.appcompat.app.AppCompatActivity;
import androidx.media3.common.MediaItem;
import androidx.media3.common.PlaybackException;
import androidx.media3.common.Player;
import androidx.media3.common.util.UnstableApi;
import androidx.media3.exoplayer.ExoPlayer;
import androidx.media3.exoplayer.hls.HlsMediaSource;
import androidx.media3.datasource.DefaultHttpDataSource;
import androidx.media3.ui.PlayerView;

import com.bumptech.glide.Glide;
import com.google.android.material.button.MaterialButton;

public class PlayerActivity extends AppCompatActivity {

    private ExoPlayer player;
    private PlayerView playerView;

    private String channelTitle, channelShort, channelCategory;
    private String channelShow, channelViewers, channelImage;
    private String streamUrl, youtubeUrl;
    private boolean isHLS;

    // Views for YouTube-only overlay
    private View overlayYoutube;
    private View overlayError;
    private View overlayLoading;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_player);

        // Get extras
        channelTitle    = getIntent().getStringExtra("channel_title");
        channelShort    = getIntent().getStringExtra("channel_short");
        channelCategory = getIntent().getStringExtra("channel_category");
        channelShow     = getIntent().getStringExtra("channel_show");
        channelViewers  = getIntent().getStringExtra("channel_viewers");
        channelImage    = getIntent().getStringExtra("channel_image");
        streamUrl       = getIntent().getStringExtra("channel_stream");
        youtubeUrl      = getIntent().getStringExtra("channel_youtube");
        isHLS           = getIntent().getBooleanExtra("channel_is_hls", false);

        setupViews();

        if (isHLS && streamUrl != null) {
            initExoPlayer();
        } else {
            showYouTubeOverlay();
        }
    }

    private void setupViews() {
        playerView     = findViewById(R.id.playerView);
        overlayYoutube = findViewById(R.id.overlayYoutube);
        overlayError   = findViewById(R.id.overlayError);
        overlayLoading = findViewById(R.id.overlayLoading);

        // Toolbar back
        ImageButton btnBack = findViewById(R.id.btnBack);
        btnBack.setOnClickListener(v -> finish());

        // Channel info bar
        TextView tvTitle   = findViewById(R.id.tvTitle);
        TextView tvMeta    = findViewById(R.id.tvMeta);
        TextView tvShort   = findViewById(R.id.tvShort);
        tvTitle.setText(channelTitle);
        tvMeta.setText(channelCategory + "  •  " + channelViewers + " assistindo");
        tvShort.setText(channelShort);

        // YouTube overlay info
        TextView ytName = findViewById(R.id.ytName);
        ytName.setText(channelTitle);

        ImageView ivYtThumb = findViewById(R.id.ivYtThumb);
        Glide.with(this).load(channelImage).into(ivYtThumb);

        MaterialButton btnOpenYT = findViewById(R.id.btnOpenYT);
        btnOpenYT.setOnClickListener(v -> openYouTube());

        // Also the button in error overlay
        MaterialButton btnRetry = findViewById(R.id.btnRetry);
        btnRetry.setOnClickListener(v -> {
            overlayError.setVisibility(View.GONE);
            overlayLoading.setVisibility(View.VISIBLE);
            initExoPlayer();
        });

        MaterialButton btnErrorYT = findViewById(R.id.btnErrorYT);
        btnErrorYT.setOnClickListener(v -> openYouTube());

        // Share button
        ImageButton btnShare = findViewById(R.id.btnShare);
        btnShare.setOnClickListener(v -> {
            Intent share = new Intent(Intent.ACTION_SEND);
            share.setType("text/plain");
            share.putExtra(Intent.EXTRA_TEXT, "Assistindo " + channelTitle + " ao vivo! " + youtubeUrl);
            startActivity(Intent.createChooser(share, "Compartilhar canal"));
        });

        // Open in YouTube button (in player bar)
        ImageButton btnYT = findViewById(R.id.btnYoutube);
        btnYT.setOnClickListener(v -> openYouTube());
    }

    @OptIn(markerClass = UnstableApi.class)
    private void initExoPlayer() {
        overlayLoading.setVisibility(View.VISIBLE);
        overlayError.setVisibility(View.GONE);
        overlayYoutube.setVisibility(View.GONE);

        if (player != null) {
            player.release();
            player = null;
        }

        player = new ExoPlayer.Builder(this).build();
        playerView.setPlayer(player);
        playerView.setVisibility(View.VISIBLE);

        DefaultHttpDataSource.Factory dataSourceFactory = new DefaultHttpDataSource.Factory()
            .setUserAgent("StreamHub/1.0")
            .setConnectTimeoutMs(15000)
            .setReadTimeoutMs(15000);

        HlsMediaSource mediaSource = new HlsMediaSource.Factory(dataSourceFactory)
            .createMediaSource(MediaItem.fromUri(Uri.parse(streamUrl)));

        player.setMediaSource(mediaSource);
        player.prepare();
        player.setPlayWhenReady(true);

        player.addListener(new Player.Listener() {
            @Override
            public void onPlaybackStateChanged(int state) {
                if (state == Player.STATE_READY) {
                    overlayLoading.setVisibility(View.GONE);
                } else if (state == Player.STATE_BUFFERING) {
                    overlayLoading.setVisibility(View.VISIBLE);
                }
            }

            @Override
            public void onPlayerError(PlaybackException error) {
                overlayLoading.setVisibility(View.GONE);
                overlayError.setVisibility(View.VISIBLE);
                TextView tvErrMsg = findViewById(R.id.tvErrMsg);
                tvErrMsg.setText("Nao foi possivel carregar o stream.\nVerifique sua conexao ou tente novamente.");
            }
        });
    }

    private void showYouTubeOverlay() {
        playerView.setVisibility(View.GONE);
        overlayLoading.setVisibility(View.GONE);
        overlayError.setVisibility(View.GONE);
        overlayYoutube.setVisibility(View.VISIBLE);
    }

    private void openYouTube() {
        if (youtubeUrl == null) return;
        try {
            // Try YouTube app first
            Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(youtubeUrl));
            intent.setPackage("com.google.android.youtube");
            startActivity(intent);
        } catch (Exception e) {
            // Fallback to browser
            Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(youtubeUrl));
            startActivity(intent);
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (player != null) player.pause();
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (player != null && isHLS) player.play();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (player != null) {
            player.release();
            player = null;
        }
    }
}

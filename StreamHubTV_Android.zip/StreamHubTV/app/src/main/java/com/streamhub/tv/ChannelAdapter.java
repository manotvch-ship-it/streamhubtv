package com.streamhub.tv;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.resource.bitmap.RoundedCorners;
import com.google.android.material.card.MaterialCardView;

import java.util.List;

public class ChannelAdapter extends RecyclerView.Adapter<ChannelAdapter.ViewHolder> {

    public interface OnChannelClickListener {
        void onChannelClick(Channel channel);
    }

    private final List<Channel> channels;
    private final OnChannelClickListener listener;

    public ChannelAdapter(List<Channel> channels, OnChannelClickListener listener) {
        this.channels = channels;
        this.listener = listener;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_channel, parent, false);
        return new ViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder h, int position) {
        Channel ch = channels.get(position);

        h.tvTitle.setText(ch.title);
        h.tvShow.setText(ch.currentShow);
        h.tvCategory.setText(ch.category);
        h.tvViewers.setText(ch.viewers + " online");
        h.tvShort.setText(ch.shortName);

        // Live badge
        h.tvLive.setVisibility(ch.isLive ? View.VISIBLE : View.GONE);

        // HLS badge
        h.tvHLS.setVisibility(ch.isHLS ? View.VISIBLE : View.GONE);

        // Thumbnail
        Glide.with(h.itemView.getContext())
            .load(ch.imageUrl)
            .transform(new RoundedCorners(16))
            .placeholder(R.drawable.placeholder_channel)
            .into(h.ivThumb);

        h.card.setOnClickListener(v -> listener.onChannelClick(ch));
    }

    @Override
    public int getItemCount() { return channels.size(); }

    static class ViewHolder extends RecyclerView.ViewHolder {
        MaterialCardView card;
        ImageView ivThumb;
        TextView tvTitle, tvShow, tvCategory, tvViewers, tvShort, tvLive, tvHLS;

        ViewHolder(View v) {
            super(v);
            card       = v.findViewById(R.id.card);
            ivThumb    = v.findViewById(R.id.ivThumb);
            tvTitle    = v.findViewById(R.id.tvTitle);
            tvShow     = v.findViewById(R.id.tvShow);
            tvCategory = v.findViewById(R.id.tvCategory);
            tvViewers  = v.findViewById(R.id.tvViewers);
            tvShort    = v.findViewById(R.id.tvShort);
            tvLive     = v.findViewById(R.id.tvLive);
            tvHLS      = v.findViewById(R.id.tvHLS);
        }
    }
}

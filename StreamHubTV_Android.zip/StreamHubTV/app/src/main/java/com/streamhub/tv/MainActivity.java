package com.streamhub.tv;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.chip.Chip;
import com.google.android.material.chip.ChipGroup;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity implements ChannelAdapter.OnChannelClickListener {

    private RecyclerView recyclerView;
    private ChannelAdapter adapter;
    private List<Channel> allChannels;
    private List<Channel> filteredChannels;
    private String activeCategory = "Todos";
    private String searchQuery = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        allChannels = ChannelRepository.getAllChannels();
        filteredChannels = new ArrayList<>(allChannels);

        setupRecyclerView();
        setupChips();
        setupSearch();
        updateCounter();
    }

    private void setupRecyclerView() {
        recyclerView = findViewById(R.id.rvChannels);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        adapter = new ChannelAdapter(filteredChannels, this);
        recyclerView.setAdapter(adapter);
    }

    private void setupChips() {
        ChipGroup chipGroup = findViewById(R.id.chipGroup);
        List<String> categories = ChannelRepository.getCategories();

        for (String cat : categories) {
            Chip chip = new Chip(this);
            chip.setText(cat);
            chip.setCheckable(true);
            chip.setChecked(cat.equals("Todos"));
            chip.setChipBackgroundColorResource(R.color.chip_bg_selector);
            chip.setTextColor(getResources().getColorStateList(R.color.chip_text_selector));
            chip.setChipStrokeColorResource(R.color.chip_stroke_selector);
            chip.setChipStrokeWidth(1f);

            chip.setOnClickListener(v -> {
                // uncheck all others
                for (int i = 0; i < chipGroup.getChildCount(); i++) {
                    ((Chip) chipGroup.getChildAt(i)).setChecked(false);
                }
                chip.setChecked(true);
                activeCategory = cat;
                applyFilter();
            });

            chipGroup.addView(chip);
        }
    }

    private void setupSearch() {
        EditText etSearch = findViewById(R.id.etSearch);
        etSearch.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            @Override public void onTextChanged(CharSequence s, int start, int before, int count) {
                searchQuery = s.toString().toLowerCase().trim();
                applyFilter();
            }
            @Override public void afterTextChanged(Editable s) {}
        });
    }

    private void applyFilter() {
        filteredChannels.clear();
        for (Channel ch : allChannels) {
            boolean matchCat = activeCategory.equals("Todos") || ch.category.equals(activeCategory);
            boolean matchQ   = searchQuery.isEmpty()
                || ch.title.toLowerCase().contains(searchQuery)
                || ch.category.toLowerCase().contains(searchQuery)
                || ch.currentShow.toLowerCase().contains(searchQuery);
            if (matchCat && matchQ) filteredChannels.add(ch);
        }
        adapter.notifyDataSetChanged();
        updateCounter();

        TextView tvEmpty = findViewById(R.id.tvEmpty);
        tvEmpty.setVisibility(filteredChannels.isEmpty() ? View.VISIBLE : View.GONE);
    }

    private void updateCounter() {
        TextView tvCount = findViewById(R.id.tvCount);
        tvCount.setText(filteredChannels.size() + " canais ao vivo");
    }

    @Override
    public void onChannelClick(Channel channel) {
        Intent intent = new Intent(this, PlayerActivity.class);
        intent.putExtra("channel_id", channel.id);
        intent.putExtra("channel_title", channel.title);
        intent.putExtra("channel_short", channel.shortName);
        intent.putExtra("channel_category", channel.category);
        intent.putExtra("channel_show", channel.currentShow);
        intent.putExtra("channel_viewers", channel.viewers);
        intent.putExtra("channel_image", channel.imageUrl);
        intent.putExtra("channel_stream", channel.streamUrl);
        intent.putExtra("channel_youtube", channel.youtubeUrl);
        intent.putExtra("channel_is_hls", channel.isHLS);
        startActivity(intent);
    }
}

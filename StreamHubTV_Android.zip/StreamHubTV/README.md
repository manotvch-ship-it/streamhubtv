# StreamHub TV — Projeto Android

## Como compilar e gerar o APK

### Pre-requisitos
- Android Studio Hedgehog 2023.1.1 ou superior
- JDK 17+
- Android SDK (minSdk 23, targetSdk 34)
- Conexao com internet para baixar as dependencias Gradle

---

## Passo a passo no Android Studio

### 1. Abrir o projeto
- Abra o Android Studio
- Clique em **"Open"** (nao "New Project")
- Navegue ate a pasta `StreamHubTV` e selecione ela
- Aguarde o Gradle sincronizar (pode demorar 2-5 min na primeira vez)

### 2. Adicionar fontes (opcional mas recomendado)
- Baixe a fonte **Syne Bold** em https://fonts.google.com/specimen/Syne
- Coloque o arquivo `.ttf` em `app/src/main/res/font/syne_bold.ttf`

### 3. Gerar APK Debug (para testar)
- No menu: **Build > Build Bundle(s) / APK(s) > Build APK(s)**
- O APK ficara em: `app/build/outputs/apk/debug/app-debug.apk`

### 4. Instalar no celular
```bash
adb install app/build/outputs/apk/debug/app-debug.apk
```
Ou transfira o arquivo APK para o celular e instale manualmente.

---

## Estrutura do projeto

```
StreamHubTV/
├── app/
│   ├── src/main/
│   │   ├── java/com/streamhub/tv/
│   │   │   ├── MainActivity.java       # Tela principal com lista de canais
│   │   │   ├── PlayerActivity.java     # Player com ExoPlayer + HLS
│   │   │   ├── ChannelAdapter.java     # RecyclerView adapter
│   │   │   ├── Channel.java            # Modelo de dados
│   │   │   └── ChannelRepository.java  # Lista de todos os canais
│   │   ├── res/
│   │   │   ├── layout/
│   │   │   │   ├── activity_main.xml   # Layout da tela principal
│   │   │   │   ├── activity_player.xml # Layout do player
│   │   │   │   ├── item_channel.xml    # Item da lista de canais
│   │   │   │   └── exo_player_controls.xml
│   │   │   ├── values/
│   │   │   │   ├── colors.xml
│   │   │   │   ├── strings.xml
│   │   │   │   └── themes.xml
│   │   │   └── drawable/               # Backgrounds e icones
│   │   └── AndroidManifest.xml
│   └── build.gradle
└── build.gradle
```

---

## Canais incluidos

### Player interno (HLS - toca direto no app):
| Canal         | Categoria     |
|---------------|---------------|
| TV Camara     | Governo       |
| TV Senado     | Governo       |
| TV Aparecida  | Religioso     |
| TV Novo Tempo | Religioso     |
| SESC TV       | Entretenimento|
| TV Cultura    | Entretenimento|
| TV Brasil     | Governo       |

### Botao YouTube (abre app do YouTube):
| Canal         | Categoria     |
|---------------|---------------|
| Caze TV       | Esportes      |
| GE TV         | Esportes      |
| SBT           | Entretenimento|
| CNN Brasil    | Noticias      |
| Band News TV  | Noticias      |
| Record News   | Noticias      |
| Band Sports   | Esportes      |

---

## Dependencias principais

```gradle
implementation 'androidx.media3:media3-exoplayer:1.2.1'
implementation 'androidx.media3:media3-exoplayer-hls:1.2.1'
implementation 'androidx.media3:media3-ui:1.2.1'
implementation 'com.github.bumptech.glide:glide:4.16.0'
```

---

## Adicionar novos canais

Edite `ChannelRepository.java` e adicione um novo `Channel`:

```java
// Canal HLS (player interno)
channels.add(new Channel(
    15,                          // ID unico
    "Meu Canal",                 // Nome
    "MCN",                       // Abreviacao (3 letras)
    "Noticias",                  // Categoria
    "Programa ao vivo",          // Descricao
    "5.0k",                      // Viewers
    "https://url-da-imagem.jpg", // Thumbnail
    "https://stream.m3u8",       // URL HLS (stream direto)
    "https://youtube.com/...",   // URL YouTube (fallback)
    true,                        // isLive
    true                         // isHLS = true para player interno
));

// Canal YouTube
channels.add(new Channel(16, "Canal YT", "YTC", "Esportes",
    "Descricao", "10k", "https://imagem.jpg",
    null,                        // sem HLS
    "https://youtube.com/@canal/live",
    true, false));               // isHLS = false
```
